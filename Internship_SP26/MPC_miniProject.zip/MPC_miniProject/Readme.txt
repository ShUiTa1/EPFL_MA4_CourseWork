This is the  MPC group project file from Mengze Tian, Yuzheng Zhu and Zhengming Zhu.

Since the Deliverable 2 are only proofs and explanations, we didn't put code here and gives our results in the report.

For reproduce the simulation results from our group, please run the corresponding deliverable file in each folders.

